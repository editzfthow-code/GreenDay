# GreenDay v6.2.0

## Baru
- 3 warna aksen baru: **Pink**, **Ungu**, dan **Merah**, masing-masing punya versi terang dan gelap. Total jadi 8 pilihan di Profil > Pengaturan > Warna aksen.
- Warna baru ikut ke warna bilah browser, cegah kedip saat aplikasi dibuka, dan impor/cadangan data.
- Kartu **"Notifikasi baru"** di Beranda (tepat di bawah kartu sapaan). Notifikasi yang belum dibaca langsung muncul di situ saat masuk, tanpa render ulang halaman. Ketuk item untuk membuka halaman terkait, atau "Tandai dibaca" untuk membersihkannya. Kartu otomatis hilang kalau tidak ada notifikasi baru.

## Perbaikan
- Notifikasi pengumuman sekarang benar-benar membawa ke kartu Pengumuman di Beranda (yang letaknya di dasar halaman) dan menyorotnya sebentar. Sebelumnya hanya pindah ke Beranda tanpa menunjukkan pengumumannya.
- Pemilih warna aksen dirapikan jadi grid 4 x 2 supaya muat di layar HP.

## Catatan
- Notifikasi di dalam aplikasi (lonceng, toast, kartu Beranda) berjalan di semua perangkat tanpa izin browser.
- Notifikasi perangkat (panel HP, di luar web) butuh browser dengan Notification API dan alamat HTTPS; di aplikasi pratinjau HTML berbasis WebView fitur ini umumnya tidak tersedia.
