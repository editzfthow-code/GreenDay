# GreenDay v6.1.0 — "Calm Grove" 🌱

**Premium Personal Productivity · AI Assistant Cici · Developer Brand: AFF&Z.AI**

GreenDay v6.0 adalah upgrade besar atas v5.7.0: desain baru yang premium-minimalist,
fitur tugas/jurnal/kebiasaan/catatan/target yang dimatangkan, Cici sebagai asisten AI
produktivitas dengan **aksi nyata**, kalender mingguan, mode fokus bebas gangguan,
statistik yang lebih dalam, dan PWA dengan notifikasi pembaruan. **Seluruh data, fitur,
dan identitas lama dipertahankan.**

---

## 📦 Isi Paket

```
greenday-v6.1.0/
├── public/greenday/
│   ├── index.html          ← Aplikasi utama v6.1.0 (SPA satu file, ±7.900 baris)
│   ├── manifest.json       ← PWA manifest v6.1.0 (+ shortcut Statistik)
│   ├── service-worker.js   ← SW cache greenday-v6.1.0 + GD_SKIP_WAITING + hangatkan font
│   ├── pengumuman.json     ← Feed pengumuman (+ entri rilis v6.0.0–v6.1.0)
│   └── icon.svg / icon-192.png / icon-512.png
├── src/app/
│   ├── page.tsx            ← Route "/" Next.js → menampilkan GreenDay (iframe)
│   └── api/cici/route.ts   ← BACKEND Cici AI v6 (chat + AI Actions + konteks)
├── package.json            ← Proyek Next.js siap jalan (BARU di v6)
├── next.config.ts / tsconfig.json / .gitignore
├── README.md               ← File ini
└── README-CICI.md          ← Dokumentasi v5.x (riwayat, dipertahankan)
```

---

## 🚀 Menjalankan

### Next.js penuh (frontend + backend AI Cici)
```bash
npm install
npm run dev        # http://localhost:3000
# produksi:
npm run build && npm start
```
Backend Cici berjalan di `/api/cici`. Frontend memanggil endpoint yang sama
(`CICI_API_URL = ""` di index.html = satu domain, tidak perlu diubah).

### Hosting statis (GitHub Pages / Netlify)
Semua fitur jalan **kecuali** chat Cici (butuh server). Isi `CICI_API_URL`
di `public/greenday/index.html` (baris konstanta di dekat atas skrip utama)
dengan alamat backend-mu, mis. `https://greenday-api.vercel.app` — backend
sudah dilengkapi CORS.

### Vercel (disarankan untuk AI penuh)
Import repo → Vercel mendeteksi Next.js otomatis → Deploy. Set environment
secret provider AI di sisi server (z-ai-web-dev-sdk membaca konfigurasi
platform). **Tidak ada API key yang disimpan di frontend.**

---

## 🌿 Rilis v6.1.0 — Rapikan, Ringankan, Lebih Manusiawi

### A. Rapikan (tanpa perubahan perilaku)
- **Lima blok `<style>` warisan patch v5.x–v6 digabung** menjadi satu stylesheet
  berurutan (token → base → komponen → halaman → responsive), lengkap dengan
  banner seksi & komentar pembatas. Aturan mati/duplikat/saling-menimpa-sama
  dibuang; urutan cascade asli dipertahankan sehingga tampilan tidak berubah.
- Versi disamakan **6.1.0** di `APP_VERSION`, `package.json`, manifest, cache
  service-worker (`greenday-v6.1.0`), README, pengumuman, dan meta description
  (yang masih tertulis "v5").
- Keempat blok `<script>` diberi banner pembatas + peta bagian (`SKRIP 1/4` …
  `4/4`); perubahan v6.1 ditandai komentar `v6.1:`.

### B. Performa (Android low–mid)
- **`backdrop-filter` disisakan hanya untuk header (sidebar), navigasi bawah,
  modal/overlay** (termasuk command palette & onboarding). Kartu, toast, chip
  fokus, gelembung Cici, kartu tur kini permukaan solid — guliran lebih murah.
- **Font 3 → 2 keluarga**: Nunito dipensiunkan (pemakaiannya di gelembung Cici,
  pesan chat, tur, onboarding diganti Plus Jakarta Sans); Fraunces + Plus Jakarta
  Sans dipertahankan. `display=swap` sudah aktif; **font kini dihangatkan ke
  cache service-worker saat install** agar tampilan offline tidak berubah.
- **Animasi hanya `transform`/`opacity`**: transisi `width` (bar progres, grafik)
  diganti `scaleX/scaleY` ber-origin kiri/bawah; seluruh 25 `@keyframes`
  diaudit — semuanya memang sudah transform/opacity — dan aturan global
  `prefers-reduced-motion` dipertahankan + dirapatkan di satu tempat.

### C. Lebih Keren
- **Beranda**: kartu **"Fokus utama hari ini"** (tugas terpenting + tombol
  *Mulai Fokus*) dan kartu **progres ring harian** (tugas · kebiasaan · fokus).
  Aksi cepat dipangkas menjadi maksimal 5 + tombol **"Lainnya"**.
- **Area bawah satu sistem**: tombol **"+" menjadi speed-dial**
  (Tugas / Jurnal / Catatan / Fokus). Cici, chip fokus, dan tombol instal kini
  punya satu aturan posisi (tak saling menumpuk/menutup konten; ikut sembunyi
  saat scroll & keyboard seperti sebelumnya).
- **Komponen konsisten**: tap target ≥44px (chip cepat, aksi kartu agenda,
  pil kalender), spasi mengikuti skala 4/8, radius & ikon seragam, kontras AA
  di mode terang dan gelap (teks redup `--faint` diterangkan di tema gelap).
- **Halus & hidup**: transisi halaman dipersingkat ke ±180ms, animasi centang
  tugas diperhalus (pop + ripple), dan **empty state ramah** — wajah Cici +
  satu tombol aksi — di halaman kosong (tugas, jurnal, kebiasaan, catatan,
  target, agenda).
- **Tema baru "Otomatis (ikuti sistem)"** di Pengaturan (Terang / Gelap /
  Otomatis) — mengikuti `prefers-color-scheme` secara langsung, anti-kedip
  sejak render pertama, bilah browser ikut menyesuaikan.

### D. Perbaikan Known Issues
- **"Jadikan tugas" dari rencana Cici tidak lagi menduplikasi** tugas yang
  sudah ada — pencocokan judul (dinormalisasi) + tanggal; item duplikat
  dilewati dan dilaporkan pada toast.
- **Sesi istirahat fokus**: kini berbunyi, bergetar (perangkat yang mendukung),
  dan mengirim **notifikasi sistem** saat selesai walau tab berada di latar
  belakang; penghitung dihitung dari *timestamp* selesai sehingga tepat walau
  timer browser dibatasi (throttled).
- **Zona waktu**: frontend mengirim tanggal & zona waktu lokal ke `/api/cici`;
  backend memakainya untuk menentukan "hari ini"/"besok" & validasi tanggal
  rencana — geseran ±1 hari untuk pengguna di luar Asia/Jakarta hilang.

---

## 🩹 Patch v6.0.1 — Perbaikan Tata Letak & Bug

Perbaikan atas laporan 3 tangkapan layar (halaman Profil & Pengaturan di HP):

- **Judul halaman terpecah** ("Pengatura / n"): judul tidak boleh lebih sempit dari
  kata terpanjangnya. Tiga tombol umum (cari, lonceng, tema) kini kelompok sendiri
  (`.pg-acts`) yang selalu utuh sebaris dengan judul; tombol khusus halaman
  (Tambah, Fokus, Bersihkan, …) pindah ke `.pg-btns` dan turun ke baris sendiri di HP
  (di layar ≥700px tetap satu baris). Di layar ≤480px, halaman yang punya tombol
  kembali menyembunyikan ubin ikon agar judul muat. Ukuran judul dibuat sedikit
  lebih luwes (`clamp(21px, 5.8vw, 30px)`).
- **Ikon bulan/matahari bergeser** dari tengah tombol tema: aturan `.theme-sw .ic`
  mengenai pembungkus `<span>` dan `<svg>` sekaligus (keduanya `absolute`). Kini hanya
  pembungkus yang `absolute` dan ikon dipusatkan dengan grid.
- **Area bawah (Cici + tombol +)**: padding bawah `.main` 238px → 168px (otomatis
  212px saat chip fokus tampil, 238px saat tombol instal tampil). Cici dan tombol +
  sama besar (56px) dan sejajar margin konten 16px. Bercak hijau latar di atas
  navigasi bawah (mode terang) diperhalus.
- **Bug Jurnal**: kartu "Refleksi minggu ini" memanggil `MOODS.find(...)` dengan id
  yang tidak ada → `TypeError` dan halaman Jurnal gagal tampil begitu ada jurnal
  dalam 7 hari terakhir. Mood kini dihitung dari jurnal 7 hari terakhir saja.
- Versi naik ke 6.0.1 (cache PWA `greenday-v6.0.1`, entri pengumuman baru).

---

## ✨ Yang Baru di v6.0.0 (Changelog)

### Desain — "Calm Grove" (Premium Minimalist)
- Token warna baru: **Sage Green** (primary), **Forest Green** (secondary),
  latar **Soft Neutral**, permukaan **Clean White**, aksen **Mint**.
- Mode gelap kembali ke identitas hijau: **Deep Green / Charcoal**.
- Radii & bayangan lebih tenang, blur diringankan (GPU hemat untuk Android
  low–mid), nuansa pink/ungu v5.7 "Taman Pagi" dipensiunkan.
- Tipografi konsisten (Plus Jakarta Sans + Fraunces untuk angka display),
  hierarchy heading dirapikan; 5 aksen dipertahankan (forest/sage/moss/ocean/sunrise)
  dengan nuansa v6.

### Data & Migrasi
- **SCHEMA_VERSION = 6** + `migrateData()` idempoten: menambah field default
  tanpa pernah menghapus/mengubah data lama (`tags`, `notes`, `completedAt`,
  `days`, `weeklyGoal`, `category`, `gratitude`, `archived`, `status`, `history`).
- Ekspor/impor cadangan tetap kompatibel; versi schema tampil di Pengaturan → Data.

### Tugas 2.0
- **Tag** (maks 8/tugas) + strip filter tag di halaman Tugas.
- **Catatan tugas** (detail pendukung: link, materi).
- **Tombol Urungkan** langsung di toast setelah tugas selesai (XP dikembalikan).
- Ringkasan harian di kepala halaman; pencarian kini mencakup tag & catatan.
- Tugas berulang kini menyalin tag & catatan.

### Kebiasaan 2.0
- **Jadwal hari fleksibel** (pilih hari apa saja) — hari libur **tidak memutus streak**;
  tombol centang nonaktif di luar jadwal (anti data palsu).
- **Target mingguan** (x× per minggu, dibatasi jumlah hari terjadwal).
- **Kategori** + **heatmap 10 minggu** per kebiasaan + kartu **Insight**
  (hari terbaik, progres target mingguan, kebiasaan sempurna).
- Streak & konsistensi dihitung hanya atas hari terjadwal.

### Jurnal 2.0
- **Rasa syukur** 3 poin per entri.
- **Prompt refleksi** acak (dapat diganti tanpa menimpa isian).
- **Autosave** saat mengetik (draf & edit) dengan indikator "Tersimpan ✓".
- **Ekspor Markdown** seluruh jurnal; **refleksi mingguan** di halaman Jurnal;
  pencarian mencakup rasa syukur & refleksi.

### Catatan 2.0
- **Tag** + **Arsip** (keluar/masuk arsip, filter Aktif/Arsip).
- Pencarian menyeluruh; autosave v5 tetap.

### Target 2.0
- **Status** (Berjalan / Selesai / Dijeda) otomatis + **riwayat aktivitas** per target.
- **Saran langkah berikutnya** di kartu target.
- **Perayaan**: confetti + notifikasi + sapaan Cici saat target 100%.

### Kalender
- **Mode Bulan / Minggu / Hari** dengan navigasi yang benar per mode.
- **Kebiasaan terjadwal** tampil di agenda harian (centang hanya untuk hari ini —
  riwayat lama tidak bisa diubah, mencegah data palsu).

### Fokus 2.0
- **Durasi kustom** 1–180 menit di samping preset Pomodoro.
- **Sesi istirahat** (5/10/15 menit) — istirahat tidak dicatat sebagai menit fokus,
  tidak memberi XP, dan tidak mengotori statistik (jujur & sehat).
- **Target fokus harian** dengan progress bar di modal.
- **Mode bebas gangguan**: overlay layar penuh yang tenang, tersinkron per detik
  dengan timer utama.

### Statistik v6
- Tren **fokus 7 hari** (menit), **ringkasan bulan ini**, **riwayat aktivitas**
  (10 XP log terakhir), plus semua statistik v5.

### Cici AI 2.0 (Smart Personal Assistant)
- **AI Actions** dengan kartu konfirmasi di chat: buat tugas, buat target,
  rencana harian (→ jadikan tugas), prioritaskan, prompt refleksi (→ tulis jurnal).
  Backend memvalidasi ketat (whitelist tipe, clamp payload, tanggal masa lalu
  dibuang); frontend mengeksekusi hanya setelah konfirmasi pengguna.
- **Context Awareness**: izin eksplisit (default **NONAKTIF**) di Pengaturan →
  Cici AI atau Pengaturan Ngobrol; ringkasan teks harian dikirim hanya saat izin aktif.
- **Aksi cepat** 7 tombol di atas kolom ketik.
- **Kirim ulang** pada pesan gagal; **Pengaturan Ngobrol** (izin konteks, aksi cepat,
  bersihkan riwayat); badge status konteks.
- Backend: rate-limit 20/menit per IP dipertahankan, input di-clamp, respons aksi
  invalid dikembalikan `null` (tidak pernah mengklaim aksi berhasil).

### Beranda
- **Rencana Hari Ini** (heuristik lokal: terlambat → prioritas → jadwal) + pintasan
  "Rencana dari Cici (AI)".
- **Tinjau Hari** & **Tinjau Mingguan** (modal ringkasan jujur + insight + langkah lanjut).
- Statistik hero kini menampilkan kebiasaan & menit fokus vs target.

### PWA & Offline
- Cache `greenday-v6.0.1`; **notifikasi pembaruan** dengan tombol "Muat ulang"
  (SW baru menunggu persetujuan, tidak memaksa refresh).
- Handler `GD_SKIP_WAITING`; strategi cache lama dipertahankan (network-first untuk
  navigasi & pengumuman, SWR untuk aset); notifikasi tugas terlambat tetap hidup
  lewat IndexedDB + Background/Periodic Sync.
- Perilaku offline jujur: chat Cici & AI Actions **butuh server** — ditampilkan
  pesan offline yang jelas; semua fitur data tetap jalan offline.

### Keamanan
- Semua render tetap lewat `esc()` (anti-XSS), termasuk tag & payload AI.
- Backend: whitelist aksi, clamp panjang semua string, tanggal validasi, rate-limit,
  tanpa secret di frontend, CORS eksplisit.
- Konteks data hanya dikirim dengan izin; berupa ringkasan teks terbatas.

---

## 🧪 Laporan Testing

Diuji pada Next.js 15.5.6 + Node 24, Chrome headless (agent-browser), viewport
desktop 1280×900 dan mobile 390×844, tema terang & gelap.

| Area | Uji | Hasil |
|---|---|---|
| Sintaks | node --check 4 blok skrip + service-worker | ✅ lulus semua |
| TypeScript | `tsc --noEmit` (route.ts + proyek) | ✅ 0 error |
| Backend chat | POST /api/cici mode chat | ✅ balasan gaya Cici, sebut AFF&Z.AI |
| Backend aksi | POST /api/cici mode action | ✅ JSON {reply, action} tervalidasi; tanggal masa lalu ditolak |
| Onboarding | isi nama + avatar + mulai | ✅ profil tersimpan |
| Tugas | buat + tag + catatan | ✅ tersimpan, chip tag tampil |
| Tugas | selesai → XP +10 → urungkan → XP kembali | ✅ |
| Migrasi | data lama tanpa field baru | ✅ field default ditambah, `done` utuh |
| Kebiasaan | jadwal Sen–Rab, target otomatis 3× | ✅; hari libur tak memutus streak |
| Jurnal | rasa syukur + autosave + simpan | ✅ |
| Jurnal | ekspor Markdown | ✅ |
| Catatan | tag + arsip + keluar arsip | ✅ |
| Target | 2 langkah → selesai semua | ✅ status "selesai", riwayat tercatat, confetti |
| Kalender | mode minggu + navigasi | ✅ 7 kolom, judul rentang benar |
| Fokus | durasi kustom 45 mnt + mode zen | ✅ overlay sinkron |
| Fokus | sesi istirahat 5 mnt selesai | ✅ tidak merekam menit fokus, tanpa XP, sesi dibersihkan |
| Statistik | halaman + ringkasan bulan + riwayat | ✅ |
| Cici chat | konteks aktif + badge | ✅ AI merujuk tugas nyata pengguna |
| Cici aksi | plan_day → "Jadikan tugas" | ✅ 3 tugas dibuat, tag rencana-cici, status done |
| Cici aksi | kartu konfirmasi buat tugas | ✅ data dibuat setelah Konfirmasi |
| Pencarian | palette: tugas & kebiasaan | ✅ |
| Tinjauan | harian & mingguan | ✅ modal + ringkasan benar |
| Pengaturan | target fokus 90 mnt tersimpan | ✅ |
| PWA | SW registrasi + cache v6 | ✅ (lihat Known Issues) |
| Konsol | error JS di semua halaman | ✅ bersih |
| Layout | desktop + mobile, terang + gelap | ✅ (screenshot diverifikasi) |

**Belum diuji otomatis** (butuh perangkat/lingkungan nyata): izin & tampilan
notifikasi push Android asli, Background/Periodic Sync terjadwal, instalasi PWA
di launcher Android, perilaku pembaruan SW di produksi, penyimpanan lintas browser.
Semua jalur ini mengikuti implementasi v5 yang sudah terbukti dan tidak diubah
logikanya, kecuali penambahan handler pembaruan (diuji lewat alur kode).

---

## ⚠️ Known Issues

1. **Chat Cici butuh server.** Hosting statis tanpa backend → Cici menampilkan
   pesan offline (dengan instruksi). Fitur lain 100% offline.
2. **Balasan AI butuh beberapa detik** (model non-streaming; indikator mengetik
   ditampilkan). Streaming belum didukung SDK.
3. **Duplikasi saat "Jadikan tugas"** dari rencana Cici: bila Cici menyarankan
   tugas yang sudah ada dan kamu konfirmasi, tugas dibuat lagi (kartu menampilkan
   isi rencana sebelum konfirmasi). Perbaikan dedup menjadi catatan iterasi berikutnya.
4. **Sesi istirahat** tidak memiliki alarm suara khusus saat selesai di latar
   (mengikuti suara & notifikasi aplikasi yang sudah ada; notifikasi push
   untuk istirahat belum lewat service worker).
5. **Periodic Background Sync** hanya aktif di Chrome Android dengan PWA terpasang
   (batasan platform, bukan bug).
6. **Impor cadangan lama**: field baru (tags, dsb.) diisi otomatis oleh migrasi;
   isi yang memakai format tak dikenal diabaikan dengan aman.
7. Tanggal aksi AI mengikuti **waktu server**; jika server berzona waktu berbeda
   dari pengguna, tanggal "hari ini" bisa bergeser ±1 hari (frontend memvalidasi
   ulang tanggal masa lalu).

---

## 🔒 Catatan Keamanan

- Tidak ada API key/secret di frontend; semua panggilan model AI lewat `/api/cici`.
- Rate-limit per IP (20 pesan/menit) aktif di backend.
- Semua input AI di-clamp dan divalidasi whitelist; aksi invalid → `null`.
- Konteks pengguna hanya dikirim bila izin aktif dan dibatasi 1.500 karakter teks.
- Data tetap 100% lokal di perangkat (LocalStorage), kecuali ringkasan konteks
  yang diizinkan pengguna.

---

## 🧭 Peta Fitur (semua fitur v5 tetap ada)

Beranda · Tugas (tag, urungkan, berulang, subtask, penanggung jawab) · Kalender
(Bulan/Minggu/Hari) · Jurnal (mood, syukur, prompt, ekspor) · Kebiasaan (jadwal,
target, heatmap) · Catatan (tag, arsip, pin, warna) · Target (status, riwayat) ·
Fokus (Pomodoro, kustom, zen) · Statistik · XP & Level & Lencana · Pusat Notifikasi
+ push · Command Palette (Ctrl+K) · Tur Fitur · Profil keluarga (multi-profil) ·
Cadangan/Impor · Ruang Cici (kustom maskot 2 model, chat AI, tips) · Pengaturan.

---

Dibuat dengan sayang oleh **AFF&Z.AI** 💚
GreenDay v6.1.0 — Calm Grove
