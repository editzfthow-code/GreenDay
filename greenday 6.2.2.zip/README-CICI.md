# GreenDay v5.6.0 — Source Code (Rombak Total, dengan Ruang Cici 💚)

Paket kode sumber lengkap aplikasi **GreenDay** versi **v5.6.0** — hasil
rombak menyeluruh: **30+ bug sekecil apapun telah diburu & ditutup**,
termasuk **Ruang Cici** (halaman khusus maskot imut + chatbot AI).

```
greenday-source/
├── public/greenday/
│   ├── index.html          ← Aplikasi utama GreenDay v5.6.0 (SPA 1 file)
│   ├── manifest.json       ← PWA manifest (v5.6.0 + shortcut Ruang Cici)
│   ├── service-worker.js   ← PWA service worker (cache v5.6.0, anti racun cache)
│   ├── pengumuman.json     ← Feed pengumuman (rilis v5.5.0–v5.6.0)
│   └── icon.svg / icon-192.png / icon-512.png
├── src/app/
│   ├── page.tsx            ← Route "/" Next.js → menampilkan GreenDay (iframe)
│   └── api/cici/route.ts   ← BACKEND chatbot Cici (CORS + rate-limit)
└── README-CICI.md          ← File ini
```

## 🛠️ Ringkasan Perbaikan v5.6.0 (Rombak Total)

**Tampilan & Layout**
- Warna mata Cici kini tampil berwarna di pilihan kustom (gradient CSS rusak).
- Chip timer fokus tidak lagi tertutup tombol Cici di HP (posisi disusun ulang);
  gelembung Cici otomatis naik saat sesi fokus berjalan.
- Pil instal tidak lagi tertimpa gelembung Cici di layar kecil.
- Toast notifikasi kini tampil di atas overlay tur/onboarding + aman dari notch.
- Teks judul panjang (tugas terlewat/notifikasi) tidak meluber kartu.
- Anti-kilat putih saat memuat di mode gelap + safe-area hidup.

**Data & Logika**
- "Hapus semua data" kini benar-benar menghapus riwayat chat Cici & menyetel
  ulang notifikasi (tidak ada lagi notifikasi hantu setelah reset).
- Aplikasi tidak lagi blank di browser yang memblokir localStorage.
- XP korup/impor liar tidak bisa membekukan tab (clamp).
- Membuat profil baru saat timer fokus berjalan tak lagi mencampur XP/menit.
- Jam malam Cici disatukan (18.00+ konsisten: teks & wajah sama-sama malam).

**Chat Cici**
- Batas waktu klien 60 detik — tombol kirim tak bisa terkunci selamanya.
- Chip cepat tidak lagi menghapus draf yang sedang diketik.
- Chip cepat ikut nama kustom maskot.
- Pesan gagal menyebut alamat server yang benar (ikut CICI_API_URL).

**Backend AI (src/app/api/cici/route.ts)**
- Rate-limit 20 pesan/menit per pengunjung (anti penyalahgunaan proxy).
- Timer timeout 50 dtk kini dibersihkan per request.

**PWA & Aksesibilitas**
- Cache offline tak bisa "diracuni" halaman lain (admin/404).
- Cache pengumuman hanya diisi respons valid.
- Notifikasi kini membuka halaman tujuannya (dulu selalu beranda).
- Ikon "Tur Fitur" kini tampil (ikon map ditambahkan).
- Judul tab browser = GreenDay (bukan scaffold).
- Beranda punya judul h1 (aksesibilitas), grafik punya label ARIA,
  panggung elus Cici bisa dioperasikan keyboard (Enter/Spasi).

## Hosting

### GitHub Pages / hosting statis
Semua fitur jalan kecuali chat AI (butuh server). Isi `CICI_API_URL`
di index.html dengan alamat backend-mu agar AI aktif — lihat panduan
paket **GreenDay-Cici-backend-vercel.zip**.

### Next.js penuh
Salin `public/` + `src/` ke project Next.js dengan `z-ai-web-dev-sdk`:
`npm install` → `npm run dev` → `http://localhost:3000`.

## Kepribadian Cici

- Imut, lembut, TIDAK kaku — memperkenalkan diri otomatis.
- WAJIB menyebut penciptanya: **AFF&Z.AI**.
- 3 gaya sapaan: `manja` / `lembut` / `semangat`.
- Riwayat 14 pesan terakhir dikirim ulang agar konteks tidak hilang.

## Contoh panggilan API

```json
POST /api/cici
{
  "messages": [{ "role": "user", "content": "halo cici!" }],
  "profile": { "userName": "NamaKamu", "ciciName": "Cici", "tone": "manja" }
}
→ { "reply": "..." }
```

Dibuat dengan sayang oleh AFF&Z.AI 💚

## v5.7.0 — Taman Pagi + Cici Robot 🤖
- Lapisan tampilan baru (latar lembut pink/ungu/hijau, sudut lebih bulat, bayangan halus, fokus keyboard jelas); aksen warna pilihan pengguna tetap bekerja.
- Model kedua: **Cici robot** (Ruang Cici → Model Cici). Gaya/warna mata, suasana wajah & aksesori tetap berlaku untuk kedua model.
- Cici lebih hidup: cincin putus-putus berputar, melompat sendiri, mata robot mengikuti jari/kursor, menyapa acak (tidak saat fokus/keyboard terbuka), bereaksi saat offline/online.
- Cache PWA dinaikkan ke v5.7.0 agar pembaruan langsung terpakai.
