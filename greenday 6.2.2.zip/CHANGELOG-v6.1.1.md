# GreenDay v6.1.1

## Perbaikan
- Ikon tombol "Agenda" di halaman Kalender yang tidak terlihat sudah dibuat terlihat lagi. Penyebabnya: ikon di dalam `.sec-head` otomatis diwarnai hijau, sama dengan warna tombol, jadi tersamarkan. Aturan `.sec-head .btn .ic{color:inherit}` ditambahkan, sehingga ikon di tombol "Tambah" (Tugas, Kebiasaan) dan "Tulis" (Jurnal) ikut terlihat juga.
- Tombol Agenda sekarang memakai ikon baru `calendarplus` (kalender dengan tanda plus).

## Kartu streak di Beranda (di-upgrade)
- Api menyala dengan efek berkedip, cincin pendar, dan percikan kecil saat streak aktif; saat streak 0 api tampil redup.
- 7 hari terakhir tampil sebagai pil bergradien hangat dengan inisial hari. Pil terisi satu per satu saat kartu tampil, dan pil hari ini berdenyut.
- Saat streak baru menyala, api muncul dengan animasi pop sekali.
- Lencana tingkat (Mulai Nyala, Bara Api, Api Menyala, Tak Terpadamkan) dan info "N hari lagi menuju streak X hari".
- Teks bantuan menyesuaikan kondisi: streak 0, aktif hari ini, atau belum aktif hari ini.

## Catatan performa dan keamanan animasi
- Semua animasi hanya memakai `transform` dan `opacity` (tanpa JS, tanpa gambar tambahan, tanpa animasi blur atau shadow).
- Animasi masuk hanya diputar saat nilai streak berubah, bukan pada setiap render ulang, jadi tidak ada kedipan berulang.
- Hormati `prefers-reduced-motion` dan aman di mode terang maupun gelap.
- Versi aplikasi dan cache PWA dinaikkan ke v6.1.1 agar perubahan langsung terpakai di HP.
