# Deploy GreenDay v6.1.0 — Singkat

## 1) Next.js penuh (frontend + Cici AI) — Vercel / VPS
```bash
npm install
npm run dev          # development → http://localhost:3000
npm run build && npm start   # produksi
```
- Cici otomatis hidup di `/api/cici` (satu domain; `CICI_API_URL = ""` — tidak perlu diubah).
- Vercel: import repo → framework Next.js terdeteksi otomatis → Deploy. Secret provider AI
  diset di sisi server (z-ai-web-dev-sdk membaca konfigurasi platform). **Tidak ada API key
  di frontend.**
- Set environment Node ≥ 18.18 (kebutuhan Next 15).

## 2) Frontend statis (GitHub Pages / Netlify) + backend terpisah
1. Deploy frontend (folder `public/greenday/` + repo) ke hosting statis.
2. Deploy project Next.js ini (atau salinan `src/app/api/cici`) sebagai backend di domain lain.
3. Di `public/greenday/index.html`, isi:
   ```js
   const CICI_API_URL = "https://backend-anda.vercel.app";
   ```
   Backend sudah mengirim header CORS — aman lintas domain.
4. Fitur non-AI tetap jalan penuh offline (LocalStorage + PWA).

## 3) Pembaruan dari v6.0.1 (pengguna existing)
- Naikkan cache service-worker (sudah: `greenday-v6.1.0`) — pengguna lama otomatis
  mendapat tawaran "Muat ulang" saat SW baru menunggu.
- Data pengguna **tidak perlu migrasi manual**: kunci LocalStorage & SCHEMA_VERSION 6
  tidak berubah; cadangan lama (format v5 sekalipun) tetap bisa diimpor.
- Setelah deploy, cek sekali: buka aplikasi → Pengaturan → "Versi schema data: 6 ·
  Aplikasi: v6.1.0".
