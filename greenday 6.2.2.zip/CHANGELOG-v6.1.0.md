# GreenDay v6.1.0 — Changelog Ringkas

Upgrade dari v6.0.1 · 7 November 2026 · Brand AFF&Z.AI · Tema "Calm Grove"

## A. Rapikan
- **5 blok `<style>` warisan patch v5.x–v6 digabung** menjadi satu stylesheet berurutan
  dengan banner: **TOKEN → BASE → KOMPONEN → HALAMAN → RESPONSIVE**. Urutan cascade asli
  dipertahankan; aturan mati/duplikat/saling-menimpa-identik dibuang
  (`.tl-empty`, `.cal-nav`, `@keyframes ccFloat`, duplikat `html{scroll-behavior}`,
  `:focus-visible`, `::selection`, `.save-ind`, `[data-theme] .plan-card`, dll).
  Tampilan diverifikasi identik lewat tangkapan layar sebelum/sesudah.
- **Versi 6.1.0 disamakan** di: `APP_VERSION`, `package.json`, `package-lock.json`,
  `manifest.json`, cache service-worker `greenday-v6.1.0`, README, `pengumuman.json`
  (entri rilis baru), meta `description` (yang masih "v5"), dan metadata layout.
- **Komentar pembatas JS**: `SKRIP 1/4` (anti-kedip tema), `SKRIP 2/4` (inti aplikasi,
  + peta bagian), `SKRIP 3/4` (PWA), `SKRIP 4/4` (lapisan Cici v5.7). Perubahan v6.1
  ditandai komentar `v6.1:`. Perilaku tidak berubah.

## B. Performa
- **`backdrop-filter` 15 aturan → 8**, hanya di: sidebar (header desktop), navigasi bawah,
  modal + overlay, command palette + overlay, onboarding + overlay. Kartu, toast, chip fokus,
  gelembung Cici, kartu tur kini **permukaan solid** (token `--glass` dinaikkan ke .92/.95 agar
  tetap terbaca). Blur overlay modal tetap direduksi di ponsel (Lite Engine v5.2 dipertahankan).
- **Font 3 → 2 keluarga**: Nunito pensiun (8 aturan CSS + 2 SVG zzz Cici diganti Plus Jakarta
  Sans); Fraunces + Plus Jakarta Sans tetap. `display=swap` aktif. **Service worker kini
  menghangatkan CSS font + berkas .woff2 saat install** → tampilan offline pertama pun sama.
- **Animasi hanya transform/opacity**: transisi `width` (bar progres, XP, sub-langkah) →
  `scaleX`; transisi `height` (grafik batang) → `scaleY` + tinggi statis via JS. Seluruh
  25 `@keyframes` diaudit — memang sudah transform/opacity — dan aturan global
  `prefers-reduced-motion` digabung jadi satu (menutup semuanya, termasuk elemen Cici).
  Pengecualian yang dipertahankan (dokumen): transisi `stroke-dashoffset` pada 3 ring SVG
  (elemen tunggal, tanpa layout) dan animasi fade halaman.

## C. Lebih Keren
1. **Beranda**: kartu **"Fokus utama hari ini"** (tugas terpenting: terlambat → prioritas
   hari ini → mendatang terdekat + tombol *Mulai Fokus*) dan kartu **"Progres hari ini"**
   dengan 3 ring: tugas · kebiasaan (terjadwal) · fokus (menit/target). Aksi cepat menjadi
   **5 + "Lainnya"** (modal Tambah Cepat memuat sisanya).
2. **Area bawah satu sistem**: tombol **"+" kini speed-dial** (Tugas / Jurnal / Catatan /
   Fokus) dengan animasi berjenjang, tutup via klik-luar / Escape / buka modal, pintasan
   keyboard **T**, `aria-expanded`. Cici (kiri), chip fokus (kiri-atas), pil instal (tengah),
   dan dial (kanan-atas) tidak pernah saling menumpuk; semua ikut menyembunyikan diri saat
   scroll turun & keyboard terbuka.
3. **Konsistensi**: tap target ≥44px (chip aksi cepat, tab, seg, chip durasi/istirahat, chip
   Cici & tag, pil kalender/statistik, tombol kecil `btn.sm`, ikon `41px` & tema diberi
   perluasan sentuh, pemilih warna catatan diberi area sentuh); skala spasi 4/8 dipertahankan;
   ikon garis seragam (1 ikon baru `dots`); **kontras AA** — `--faint` terang 4.19→4.9,
   `--primary` teks terang 3.8→4.7 (nuansa sage tetap); mode gelap sudah ≥5.0 semua.
4. **Halus & hidup**: transisi halaman 420ms → **200ms** (±180ms), masuk kartu 500→400ms,
   animasi centang tugas dipertahankan (pop + ripple + confetti), **empty state ramah**:
   wajah Cici menyapa + tombol aksi di halaman kosong (tugas, jurnal, kebiasaan, catatan,
   target, statistik, agenda).
5. **Tema "Otomatis (ikuti sistem)"**: Pengaturan kini Terang / Gelap / **Otomatis** —
   mengikuti `prefers-color-scheme` secara langsung (listener perubahan sistem), anti-kedip
   sejak render pertama, bilah browser mengikuti; tombol tema di topbar turun dari "auto"
   dengan cerdas (memilih kebalikan tema sistem saat itu).

## D. Perbaikan Known Issues
- **"Jadikan tugas" tidak menduplikasi**: aksi `create_task` & `plan_day` dari Cici kini
  memeriksa tugas existing dengan pencocokan **judul dinormalisasi + tanggal sama**
  (tahan beda huruf/spasi). Item duplikat dilewati & dilaporkan di toast
  ("… (N duplikat dilewati)"); aksi ditandai selesai (idempoten).
- **Sesi istirahat fokus**: sisa waktu dihitung dari **timestamp selesai** (`endAt`) —
  kebal throttling timer tab latar; `setTimeout` pengaman menyala tepat saat durasi habis.
  Saat selesai: **bunyi** (SFX + resume AudioContext), **getar** (`navigator.vibrate`),
  dan **notifikasi sistem** via service worker bila izin notifikasi diizinkan — plus
  notifikasi in-app seperti sebelumnya. Sesi fokus selesai pun dapat notifikasi sistem.
- **Zona waktu**: frontend kirim `client: {date, timezone, offset}` ke `/api/cici`; backend
  memakai tanggal klien untuk "hari ini"/"besok" & validasi tanggal rencana
  (fallback: tanggal server). Geseran ±1 hari (dulu memakai UTC/Asia-Jakarta server) hilang.

## Perbaikan tambahan saat audit
- **ID ganda `fcZen`** (tombol modal vs overlay zen) → overlay kini `fcZenOv`;
  `getElementById` tidak lagi salah sasaran.

## Kompatibilitas data
- Kunci LocalStorage, `SCHEMA_VERSION 6`, format backup/impor **tidak berubah**.
  Semua fitur & identitas lama utuh. Diuji: impor cadangan format v5 → data + tema diterapkan.
